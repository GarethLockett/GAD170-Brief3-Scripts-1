﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
    Script: Item
    Author: Gareth Lockett
    Version: 1.0
    Description: Base class that all items inherit from.
*/

public abstract class Item : MonoBehaviour
{
    // Properties
    public string itemName;         // Name of the item.
    public string description;      // Short description of the item.

    // Methods
    public abstract void Activate( Character characterActivating ); // Called whenever the item is 'activated' (eg weapon fired, potion drank etc)
}
