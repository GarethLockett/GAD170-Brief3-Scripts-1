﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
    Script: CharacterController
    Author: Gareth Lockett
    Version: 1.0
    Description: Base class for all movement controllers (eg player, enemy)
*/

public abstract class CharacterController : MonoBehaviour
{
    public float moveSpeed = 1f;                        // Player translation speed.
    public float turnSpeed = 45f;                       // Player rotation speed.
    public float jumpAmount = 5f;                      // Force amount to jump up.
}
