﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
    Script: CharacterPlayer
    Author: Gareth Lockett
    Version: 1.0
    Description: The player's main class. Handles player input and movement.
*/

public class CharacterPlayer : Character
{
    // Properties

    // *NOTE: Could use the Input manager to set these up instead.
    public KeyCode moveForwardKey = KeyCode.W;          // Move forward key.
    public KeyCode moveBackwardKey = KeyCode.S;         // Move backward key.
    public KeyCode rotateLeftKey = KeyCode.A;           // Rotate left key.
    public KeyCode rotateRightKey = KeyCode.D;          // Rotate right key.
    public KeyCode fireKey = KeyCode.Space;             // Trigger attached items to activate (eg weapon to fire) 
    public KeyCode jumpKey = KeyCode.E;                 // Jump upward key.

    public float moveSpeed = 1f;                        // Player translation speed.
    public float turnSpeed = 45f;                       // Player rotation speed.
    public float jumpAmount = 5f;                      // Force amount to jump up.

    private Camera childCamera;                         // This will contain a reference to a child camera (If has one)

    // Methods
    private void Start()
    {
        // Will grab a reference to a child camera. If it does not have one (or camera/GameObject is disabled) it will not do camera mouse look.
        this.childCamera = this.GetComponentInChildren<Camera>();
        if( this.childCamera.gameObject.activeInHierarchy == false || this.childCamera.enabled == false ){ this.childCamera = null; }
        
        // Hide/lock the cursor if has a child camera (eg FPS)
        if( this.childCamera != null ){ Cursor.lockState = CursorLockMode.Locked; }
    }

    private void Update()
    {
        // Call the parent class UpdateParent() here so any default Character class update code happens.
        if( base.UpdateParent() == false ){ return; }

        // Check player input and set move direction.
        Vector3 moveDirection = Vector3.zero;
        if( Input.GetKey( this.moveForwardKey ) == true ){ moveDirection += this.transform.forward; }
        if( Input.GetKey( this.moveBackwardKey ) == true ){ moveDirection -= this.transform.forward; }

        // Check if we have a child camera for mouse look (FPS) or else use left/right keys to rotate.
        if( this.childCamera != null )
        {
            // Get the amount the mouse has moved since last Update()
            Vector2 mouseDelta = Vector2.zero;
            float mouseSensitivity = 10f; // Play around with mouse look speed
            mouseDelta.x = Input.GetAxis( "Mouse X" ) *mouseSensitivity;
            mouseDelta.y = Input.GetAxis( "Mouse Y" ) *mouseSensitivity *2f;

            // Rotate this game object around its' Y axis (For the horizontal mouse look)
            this.transform.Rotate( this.transform.up, Time.deltaTime *this.turnSpeed *mouseDelta.x );
            
            // Rotate the child camera using the mouse Y delta by moving the forward vector up or down.
            Vector3 forwardVec = this.childCamera.transform.forward;
            forwardVec.y += Time.deltaTime *this.turnSpeed *( mouseDelta.y / Screen.height );
            this.childCamera.transform.forward = forwardVec;

            // Strafe by adding to the current move direction.
            if( Input.GetKey( this.rotateLeftKey ) == true ){ moveDirection -= this.transform.right; }
            if( Input.GetKey( this.rotateRightKey ) == true ){ moveDirection += this.transform.right; }
        }
        else
        {
            if( Input.GetKey( this.rotateLeftKey ) == true ){ this.transform.Rotate( this.transform.up, Time.deltaTime *-this.turnSpeed ); }
            if( Input.GetKey( this.rotateRightKey ) == true ){ this.transform.Rotate( this.transform.up, Time.deltaTime *this.turnSpeed ); }
        }

        // Do the actual move by normalizing (eg make a 'unit vector') the move direction and then multiply it by time and player movement speed.
        this.transform.position += moveDirection.normalized *Time.deltaTime *this.moveSpeed;

        // Check for player pressing the fire key.
        //if( Input.GetKey( this.fireKey ) == true )
        if( Input.GetKey( this.fireKey ) == true || Input.GetMouseButton( 0 ) == true ) // Include mouse button to firing? (FPS)
        {
            // Get any child objects who are items.
            Item[] items = this.GetComponentsInChildren<Item>();

            // Called the Activate() method on each item.
            foreach( Item item in items ){ item.Activate( this ); }
        }

        // Press escape key to show cursor again (eg If FPS)
        if( Input.GetKey( KeyCode.Escape ) == true ){ Cursor.lockState = CursorLockMode.None; }
    }
    
    public override void ProjectileHit( Projectile projectile )
    {
        // Subtract the projectiles damage amount from the player's health.
        this.health -= projectile.damage;

Debug.Log( "Player got hit by a projectile from " +projectile.GetSourceCharacter().gameObject.name );
    }

    // Physics calls should only be done in FixedUpdate()
    private void FixedUpdate()
    {
        // Handle jumping.
        if( Input.GetKey( this.jumpKey ) == true )
        {
            // Check the character is standing on something (NOTE: May want to change this to detect what it is standing on)
            if( Physics.Raycast( this.transform.position, -Vector3.up, 1f ) == true )
            {
                // Use physics system to add some upward force.
                this.GetComponent<Rigidbody>().AddForce( Vector3.up *this.jumpAmount, ForceMode.Impulse );
            }
        }
    }
}