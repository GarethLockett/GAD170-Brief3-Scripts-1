﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

/*
    Script: Enemy
    Author: Gareth Lockett
    Version: 1.0
    Description: Simple enemy script. 
*/

[ RequireComponent( typeof( NavMeshAgent ) ) ]
public class Enemy : Character
{
    // Enumerators
    protected enum EnemyState{ _idle, _targetingPlayer }

    // Properties

    protected EnemyState enemyState;        // Enemy specific states.

    private NavMeshAgent navMeshAgent;      // Reference to the NavMeshAgent component.

    // Methods
    private void Start()
    {
        this.navMeshAgent = this.GetComponent<NavMeshAgent>();
    }

    private void Update()
    {
        // Call the parent class UpdateParent() here so any default Character class update code happens.
        if( base.UpdateParent() == false ){ return; }

        // Do enemy current state
        switch( this.enemyState )
        {
            case EnemyState._idle: break;

            case EnemyState._targetingPlayer:
                //this.navMeshAgent.SetDestination(  ); ..... get player .. GameManager
                break;
        }
    }

    // private override void DoIdleState()
    // {
    //     // What to do/check when this enemy is idle?
    // }
}
