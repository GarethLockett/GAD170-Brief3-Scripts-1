﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
    Script: Character
    Author: Gareth Lockett
    Version: 1.0
    Description: Base class that all characters inherit from.
                Uses physics (rigidbody) Make sure to set rotation constraints, so character doesn't fall over.
*/

[ RequireComponent( typeof( Rigidbody) ) ]
public abstract class Character : MonoBehaviour
{
    // Enumerators
    public enum CharacterState{ _idle, _dead }      // <<< Add more states here.

    // Properties
    public float health = 10f;                      // Amount of health the character has.

    protected CharacterState characterState;        // The current state of the character (eg idle, dead ...)

    private Rigidbody rigidbody;                    // Reference to the rigidbody component.

    // Methods
    private void Awake()
    {
        this.rigidbody = this.GetComponent<Rigidbody>();
    }

    public virtual void ProjectileHit( Projectile projectile ){}

    // Allows other scripts to check the state of this character without been able to change it.
    public CharacterState GetState(){ return this.characterState; }

    // Call this from child classes. Return true to continue doing child class, or false to tell child class not to continue executing.
    protected bool UpdateParent()
    {
        // Check for player death (eg health <= 0)
        if( this.health <= 0f )
        {
            // TODO: What happens when players' health is equal to or less than 0?
            return false;
        }

        // Do any generic character states
        switch( this.characterState )
        {
            case CharacterState._idle: this.DoIdleState(); break;
            case CharacterState._dead: this.DoDeadState(); break;
        }

        return true;
    }

    // What to do/check when this character is idle?
    protected virtual void DoIdleState()
    {
        // Set idle animation...
    }

    // What to do/check when this character is dead?
    protected virtual void DoDeadState()
    {
        // Make sure death animation playing/played...
    }
}
